﻿using LiveCharts;
using LiveCharts.Wpf;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace RecipeApp
{
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes;

        public MainWindow()
        {
            InitializeComponent();
            LoadRecipes();
        }

        private void LoadRecipes()
        {
            // Load the recipes data here, e.g:
            recipes = new List<Recipe>
            {
                new Recipe { Name = "Recipe 1", Ingredients = "Tomato, Carrot", FoodGroup = "Vegetable", Calories = 200 },
                new Recipe { Name = "Recipe 2", Ingredients = "Chicken, Beef", FoodGroup = "Meat", Calories = 300 },
                new Recipe {Name = "Recipe 3", Ingredients = "Cheese, Yogurt", FoodGroup = "Dairy", Calories = 150}
                // You can add more sample recipes
            };
            RecipesDataGrid.ItemsSource = recipes;
        }

        private void FilterByIngredient_Click(object sender, RoutedEventArgs e)
        {
            string ingredient = IngredientTextBox.Text.ToLower();
            var filteredRecipes = recipes.Where(r => r.Ingredients.ToLower().Contains(ingredient)).ToList();
            RecipesDataGrid.ItemsSource = filteredRecipes;
        }

        private void FilterByFoodGroup_Click(object sender, RoutedEventArgs e)
        {
            if (FoodGroupComboBox.SelectedItem is ComboBoxItem selectedItem)
            {
                string foodGroup = selectedItem.Content.ToString();
                var filteredRecipes = recipes.Where(r => r.FoodGroup == foodGroup).ToList();
                RecipesDataGrid.ItemsSource = filteredRecipes;
            }
        }

        private void FilterByCalories_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(MaxCaloriesTextBox.Text, out int maxCalories))
            {
                var filteredRecipes = recipes.Where(r => r.Calories <= maxCalories).ToList();
                RecipesDataGrid.ItemsSource = filteredRecipes;
            }
            else
            {
                MessageBox.Show("Please enter a valid number for calories.");
            }
        }

        private void GeneratePieChart_Click(object sender, RoutedEventArgs e)
        {
            var selectedRecipes = RecipesDataGrid.ItemsSource as List<Recipe>;
            if (selectedRecipes == null || !selectedRecipes.Any())
            {
                MessageBox.Show("No recipes to display in the chart.");
                return;
            }

            var foodGroupCounts = selectedRecipes.GroupBy(r => r.FoodGroup)
                                                 .Select(g => new { FoodGroup = g.Key, Count = g.Count() })
                                                 .ToList();

            PieChart.Series = new SeriesCollection();
            foreach (var group in foodGroupCounts)
            {
                double totalRecipes = 0;
                double percentage = (group.Count / (double)totalRecipes) * 100;
                PieChart.Series.Add(new PieSeries
                {
                    Title = group.FoodGroup,
                    Values = new ChartValues<double> { percentage, group.Count },
                   

                    DataLabels = true,
                    LabelPoint = chartPoint => $"{chartPoint.Y:F2}%"
                });
            }
        }
    }

    public class Recipe
    {
        public string Name { get; set; }
        public string Ingredients { get; set; }
        public string FoodGroup { get; set; }
        public int Calories { get; set; }
    }
}
